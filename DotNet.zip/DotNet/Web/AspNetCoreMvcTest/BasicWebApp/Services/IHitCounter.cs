namespace BasicWebApp.Services;

public interface IHitCounter
{
    int CountNext(string name);
}