﻿namespace RichClientApp
{
    public class Product
    {
        public int ProductNo { get; set; }

        public decimal Price { get; set; }
    }
}
