namespace Finance;

public class EducationLoan
{
    [MaxDuration]
    public float Common(double amount, int period) => 6;

    public float Masters(double amount, int period) => 7;
}

