namespace Met.Banking;

public interface IProfitable
{
    double AddInterest(int months);
}
