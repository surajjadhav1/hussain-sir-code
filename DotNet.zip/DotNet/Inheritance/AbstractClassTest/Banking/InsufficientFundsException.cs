namespace Banking;

//a type defined with public modifier is visible outside of
//its assembly (Project)
public class InsufficientFundsException : ApplicationException {}
